
import React, { useState, useRef, useEffect } from 'react';
import { ARSModel, Message, ChatSession } from './types';
import { generateARSResponse } from './services/geminiService';
import ChatMessage from './components/ChatMessage';
import ModelSelector from './components/ModelSelector';

const App: React.FC = () => {
  const [model, setModel] = useState<ARSModel>(ARSModel.FLASH);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: Date.now(),
    };

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: '',
      model: model,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage, assistantMessage]);
    setInput('');
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role === 'user' ? 'user' as const : 'model' as const,
      parts: [{ text: m.content }]
    }));
    history.push({ role: 'user', parts: [{ text: input }] });

    try {
      await generateARSResponse(model, history, (chunk) => {
        setMessages(prev => prev.map(m => 
          m.id === assistantMessage.id ? { ...m, content: chunk } : m
        ));
      });
    } catch (err) {
      setMessages(prev => prev.map(m => 
        m.id === assistantMessage.id ? { ...m, content: "Maaf, ARS AI sedang mengalami gangguan koneksi. Silakan coba lagi nanti." } : m
      ));
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex h-screen w-full bg-zinc-950 overflow-hidden font-inter">
      {/* Sidebar - Desktop Only for now */}
      <aside className="w-72 border-r border-zinc-800 bg-zinc-950 flex flex-col hidden md:flex">
        <div className="p-4">
          <button className="w-full flex items-center gap-3 px-3 py-3 rounded-lg border border-zinc-700 hover:bg-zinc-900 transition-colors text-zinc-100 font-medium">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
            New Chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-2 space-y-2">
           <div className="text-zinc-600 text-[11px] font-bold uppercase tracking-widest px-2 mb-2">History</div>
           <div className="px-3 py-2 text-zinc-500 text-sm italic">No recent chats.</div>
        </div>
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">D</div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-zinc-100 truncate">Ditz</div>
              <div className="text-[10px] text-indigo-400 font-bold uppercase">Main Developer</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Header */}
        <header className="absolute top-0 w-full z-10 p-4 flex justify-center items-center pointer-events-none">
          <div className="pointer-events-auto">
            <ModelSelector selectedModel={model} onSelect={setModel} />
          </div>
        </header>

        {/* Messages Area */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto pt-24 pb-40 scroll-smooth"
        >
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center px-6 text-center">
              <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl mb-8 animate-pulse">
                 <span className="text-4xl font-black text-white italic">A</span>
              </div>
              <h1 className="text-4xl font-bold text-zinc-100 mb-4 tracking-tight">How can I help you today?</h1>
              <p className="text-zinc-500 max-w-lg leading-relaxed">
                Experience ARS AI, the advanced intelligence system developed by Ditz. 
                Powerful enough to rival the world's best.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-12 max-w-2xl w-full">
                {[
                  "Explain quantum entanglement like I'm five",
                  "Write a Python script to scrape news headlines",
                  "Plan a 7-day trip to Tokyo and Kyoto",
                  "How do I optimize a React application?"
                ].map((prompt, i) => (
                  <button 
                    key={i}
                    onClick={() => { setInput(prompt); }}
                    className="p-4 text-left rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 transition-colors text-zinc-400 text-sm"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((m) => (
              <ChatMessage key={m.id} message={m} />
            ))
          )}
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 w-full p-4 md:p-8 bg-gradient-to-t from-zinc-950 via-zinc-950 to-transparent">
          <div className="max-w-4xl mx-auto relative group">
            <form 
              onSubmit={handleSubmit}
              className="relative flex items-end gap-2 bg-zinc-900 rounded-2xl border border-zinc-800 shadow-2xl focus-within:border-zinc-700 transition-all p-2"
            >
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Message ARS AI..."
                rows={1}
                className="w-full bg-transparent border-none focus:ring-0 text-zinc-200 py-3 px-4 resize-none max-h-60 overflow-y-auto"
                style={{ height: 'auto', minHeight: '44px' }}
              />
              <button
                disabled={isLoading || !input.trim()}
                type="submit"
                className={`p-2.5 rounded-xl transition-all ${
                  isLoading || !input.trim() 
                  ? 'text-zinc-700' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-600/30'
                }`}
              >
                {isLoading ? (
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 10l7-7m0 0l7 7m-7-7v18"></path></svg>
                )}
              </button>
            </form>
            <div className="mt-2 text-center text-[10px] text-zinc-600">
               ARS AI can make mistakes. Developed by <span className="text-indigo-500 font-bold">Ditz</span>. Check important info.
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
