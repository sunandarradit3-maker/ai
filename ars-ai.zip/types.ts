
export enum ARSModel {
  FLASH = 'ARS Flash',
  PRO = 'ARS Pro',
  THINKING = 'ARS Thinking'
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  model?: ARSModel;
  timestamp: number;
  thinking?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  updatedAt: number;
}
