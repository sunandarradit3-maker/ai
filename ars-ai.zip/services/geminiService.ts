
import { GoogleGenAI, GenerateContentResponse, GenerateContentParameters } from "@google/genai";
import { ARSModel } from "../types";

const API_KEY = process.env.API_KEY || "";

export const getModelId = (model: ARSModel): string => {
  switch (model) {
    case ARSModel.FLASH:
      return 'gemini-3-flash-preview';
    case ARSModel.PRO:
      return 'gemini-3-pro-preview';
    case ARSModel.THINKING:
      return 'gemini-3-pro-preview'; // Thinking is a config on Pro
    default:
      return 'gemini-3-flash-preview';
  }
};

export const generateARSResponse = async (
  model: ARSModel,
  history: { role: 'user' | 'model'; parts: { text: string }[] }[],
  onChunk: (text: string) => void
) => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const modelId = getModelId(model);
  
  const config: any = {
    temperature: 0.7,
    topP: 0.95,
  };

  if (model === ARSModel.THINKING) {
    config.thinkingConfig = { thinkingBudget: 32768 };
  }

  const prompt = history[history.length - 1].parts[0].text;
  const previousContext = history.slice(0, -1);

  try {
    const result = await ai.models.generateContentStream({
      model: modelId,
      contents: history.map(h => ({
        role: h.role,
        parts: h.parts
      })),
      config,
    });

    let fullText = "";
    for await (const chunk of result) {
      const text = chunk.text;
      if (text) {
        fullText += text;
        onChunk(fullText);
      }
    }
    return fullText;
  } catch (error) {
    console.error("ARS AI API Error:", error);
    throw error;
  }
};
