
import React from 'react';
import { ARSModel } from '../types';

interface ModelSelectorProps {
  selectedModel: ARSModel;
  onSelect: (model: ARSModel) => void;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ selectedModel, onSelect }) => {
  const models = [
    { id: ARSModel.FLASH, desc: 'Fastest & Efficient', icon: '⚡' },
    { id: ARSModel.PRO, desc: 'Most Capable & Versatile', icon: '💎' },
    { id: ARSModel.THINKING, desc: 'Advanced Deep Reasoning', icon: '🧠' },
  ];

  return (
    <div className="flex gap-2 p-1 bg-zinc-900 rounded-xl border border-zinc-800 shadow-2xl">
      {models.map((m) => (
        <button
          key={m.id}
          onClick={() => onSelect(m.id)}
          className={`flex flex-col items-start px-4 py-2 rounded-lg transition-all duration-200 min-w-[140px] ${
            selectedModel === m.id 
              ? 'bg-zinc-800 border border-zinc-700 shadow-sm text-white' 
              : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50'
          }`}
        >
          <div className="flex items-center gap-2 font-semibold text-sm">
            <span>{m.icon}</span>
            <span>{m.id}</span>
          </div>
          <span className="text-[10px] opacity-70">{m.desc}</span>
        </button>
      ))}
    </div>
  );
};

export default ModelSelector;
