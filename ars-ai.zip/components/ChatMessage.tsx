
import React from 'react';
import { Message, ARSModel } from '../types';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isAssistant = message.role === 'assistant';

  return (
    <div className={`flex w-full py-8 ${isAssistant ? 'bg-zinc-900/50' : 'bg-transparent'}`}>
      <div className="max-w-4xl mx-auto w-full px-4 flex gap-6">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
          isAssistant ? 'bg-indigo-600 text-white font-bold' : 'bg-zinc-700 text-zinc-300'
        }`}>
          {isAssistant ? 'A' : 'U'}
        </div>
        <div className="flex-1 space-y-4 overflow-hidden">
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm text-zinc-100 uppercase tracking-tight">
              {isAssistant ? `ARS ${message.model || 'AI'}` : 'You'}
            </span>
            {isAssistant && message.model === ARSModel.THINKING && (
               <span className="text-[10px] px-1.5 py-0.5 rounded border border-indigo-500/50 text-indigo-400 font-medium">DEEP REASONING</span>
            )}
          </div>
          
          <div className="text-zinc-300 leading-relaxed whitespace-pre-wrap break-words">
            {message.content || (
              <div className="flex gap-1 mt-2">
                <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
